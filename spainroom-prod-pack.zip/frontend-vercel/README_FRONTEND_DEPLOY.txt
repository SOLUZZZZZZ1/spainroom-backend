1) Copia `vercel.json` a la raíz del frontend.
2) Sustituye https://TU-BACKEND-HTTPS por la URL real de tu backend.
3) vercel build → vercel deploy --prebuilt (preview) → vercel promote (producción).
